<?php
//
// modern_gauge URL Dashlet 
// Copyright (c) 2008-2022 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../dashlethelper.inc.php');
include_once(dirname(__FILE__) . '/gaugeshelper.php');

// Run the initialization function
modern_gauge_init();

function modern_gauge_init()
{
	$name = "modern_gauge";
	
	$args = array(
		DASHLET_NAME => $name,
		DASHLET_VERSION => "1.0.0",
		DASHLET_DATE => "12/27/2022",
		DASHLET_AUTHOR => "Nagios Enterprises, LLC",
		DASHLET_DESCRIPTION => _("Modern Gauge Dashlet.	"),
		DASHLET_COPYRIGHT => "Copyright (c) 2010-2022 Nagios Enterprises, LLC",
		DASHLET_LICENSE => "BSD",
		DASHLET_HOMEPAGE => "www.nagios.com",
		DASHLET_REFRESHRATE => 60,
		DASHLET_FUNCTION => "modern_gauge_func",
		DASHLET_TITLE => _("Modern Gauge Dashlet"),
		DASHLET_OUTBOARD_CLASS=> "modern_gauge_outboardclass",
		DASHLET_INBOARD_CLASS => "modern_gauge_inboardclass",
		DASHLET_PREVIEW_CLASS => "modern_gauge_previewclass",
		DASHLET_JS_FILE => "modern_gauge.js",
		DASHLET_WIDTH => "300",
		DASHLET_HEIGHT => "200",
		DASHLET_OPACITY => "1.0"
	);
		
	register_dashlet($name, $args);
}
	

function modern_gauge_func($mode=DASHLET_MODE_PREVIEW, $id="", $args=null)
{
	$output = "";

	switch ($mode) {

		case DASHLET_MODE_GETCONFIGHTML:
			//input form for dashlet vars 
			if ($args == null) {
                $output = '<script type="text/javascript">load_gauge_hosts();</script>';
                $output .= '<div class="popup-form-box"><label>' . _('Host') . '</label>
                            <div><select id="gauges_form_name" class="form-control" name="host" onchange="getgaugejson()">
                                    <option selected></option>';
                $output .= '</select> <i class="fa fa-spinner fa-spin fa-14 hide host-loader" title="'._('Loading').'"></i></div></div>';
                $output .= '<div class="popup-form-box"><label>' . _('Services') . '</label>
                                <div id="gauges_services">
                                    <select id="gauges_form_services" class="form-control" name="service" onchange="getgaugeservices()" disabled>
                                        <option selected></option>
                                    </select> <i class="fa fa-spinner fa-spin fa-14 hide service-loader" title="'._('Loading').'"></i>
                                    <div id="empty-services" class="hide">'._("No services found").'</div>
                                </div>
                            </div>';
                $output .= '<div class="popup-form-box"><label>' . _('Datasource') . '</label>
                                <div id="gauges_datasource">
                                    <select id="gauges_form_ds" class="form-control" name="ds" disabled>
                                        <option selected></option>
                                    </select> <i class="fa fa-spinner fa-spin fa-14 hide ds-loader" title="'._('Loading').'"></i>
                                    <div id="empty-ds" class="hide">'._("No data sources found").'</div>
                                </div>
                            </div>';
                $output .= '';
            }
            break;

		case DASHLET_MODE_OUTBOARD:
		case DASHLET_MODE_INBOARD:

			$output = "";
            if (empty($args['ds'])) {
                $output .= "ERROR: Missing Arguments";
                break;
            }

			// Random dashlet id 
			$rand = rand();
            
            $refresh_rate = $args["refresh"] * 1000;

			$n = 0;
            $ajaxargs = "{";
            foreach ($args as $idx => $val) {
                if ($n > 0)
                    $ajaxargs .= ", ";
                $ajaxargs .= "\"$idx\" : \"$val\"";
                $n++;
            }
            $ajaxargs .= "}";

			$uri = $_SERVER['REQUEST_URI'];

			// HTML output (heredoc string syntax)
			$output = insert_modern_gauge_html('modern_gauge_dashlet{'.$rand.'}');
			$output .= "<script>

			// console.log('".$uri."');
			
			".ajax_update_gauge($id, $args)."
				var elem = $('#dashletcontainer-".$id."');
				// console.table(".json_encode($args).");
				elem.on('resizestop', function(e, ui) {
					
					const size = Math.min(ui.size.width,ui.size.height);
					console.log(size, ui);

					// const circles = $('#dashlet-".$id." svg circle');
					// circles.each(function(){
					// 	$(this).attr('r', size/4);
					// 	$(this).attr('cx', size/4);
					// 	$(this).attr('cy', size/4);
					// });
					
					//nvm, for some reason the scaling stopped working
					//don't do the above, just scale it up instead.
					const newscale = (size-20)/70;
					console.log(newscale);
					$('modern_gauge_dashlet{".$rand."}').children().scale(newscale);
				});

				// var args = ".$ajaxargs."; //".json_encode($ajaxargs).";

				// console.log(".json_encode($args).");

				// console.log(String.raw`".$id." svg.modern_gauge_svg`);


				//// add modification menu
				// toggle menu button
				var dashletmodifications = document.querySelector('#dashletcontainer-".$id." .dashlettopbox .dashboarddashletcontrol .dashletconfigure');
				dashletmodifications.classList.add('tt-bind');
				dashletmodifications.style.width = '16px';
				dashletmodifications.style.height = '16px';
				dashletmodifications.style.display = 'block';
				dashletmodifications.style.textAlign = 'center';
				dashletmodifications.style.marginLeft = '3px';
				dashletmodifications.setAttribute('data-original-title', 'Customize');
				dashletmodifications.querySelector('a').onclick = function() { toggle(this.nextElementSibling); }

				var dashmodbtn = dashletmodifications.querySelector('a').appendChild(document.createElement('i'));
				dashmodbtn.classList.add('fa', 'fa-cog');

				function toggle(item){
					if (item.style.display === 'none') {
						item.style.display = 'block';
					} else {
						item.style.display = 'none';
					}
				}

				// modifications menu
				var dashModMenu = dashletmodifications.appendChild(document.createElement('div'));
				dashModMenu.classList.add('dashlet-modify-menu');
				// dashModMenu.style.width = '40px';
				dashModMenu.style.height = '40px';
				dashModMenu.style.display = 'none';
				dashModMenu.style.backgroundColor = 'grey';
	
				var dashModMenuForm = dashModMenu.appendChild(document.createElement('form'));
				dashModMenuForm.style.backgroundColor = '#555';
				dashModMenuForm.style.width = '125px';
				dashModMenuForm.style.height = '40px';
				dashModMenuForm.style.alignItems = 'center';
				dashModMenuForm.style.verticalAlign = 'middle';

				// var dMMFInput = dashModMenuForm.appendChild(document.createElement('input'));
				// dMMFInput.style.width = '35px';
				// dMMFInput.placeholder = 'Stroke';
				// dMMFInput.style.backgroundColor = '#777';
				// dMMFInput.style.color = '#ccc';
				// dMMFInput.style.display = 'inline-block';
				// dMMFInput.style.border = '3px solid #555';
				// var dMMFInSubmit = dashModMenuForm.appendChild(document.createElement('button'));
				// dMMFInSubmit.style.width = '89px';
				// dMMFInSubmit.innerHTML = 'Stroke Width';
				// dMMFInSubmit.style.fontSize = 'x-small';
				// dMMFInSubmit.style.display = 'inline-block';
				// dMMFInSubmit.style.backgroundColor = '#444';
				// dMMFInSubmit.style.border = '3px solid #555';
				// dMMFInSubmit.onclick = function() { 
				// 	if (dMMFInput.value > 0){
				// 		localStorage.setItem('".$id."-stroke-width', dMMFInput.value);
				// 		setstrokewidth('".$id."', localStorage.getItem['".$id."-stroke-width']); 
				// 	}
				// }
				// if(localStorage.getItem('".$id."-stroke-width') != null) { setstrokewidth('".$id."', localStorage.getItem['".$id."-stroke-width']); }

				var dMMFTogglezones = dashModMenuForm.appendChild(document.createElement('button'));
				dMMFTogglezones.innerHTML = 'Toggle Zones';
				dMMFTogglezones.value = 'ToggleZones';
				dMMFTogglezones.classList.add('togglezones');
				dMMFTogglezones.style.width = '125px';
				// dMMFTogglezones.style.height = '20px';
				dMMFTogglezones.style.backgroundColor = '#444';
				dMMFTogglezones.style.border = '3px solid #555';
				dMMFTogglezones.onclick = function() { 
					if(localStorage.getItem('hidezones".$id."') == 1) { 
						localStorage.setItem('hidezones".$id."', 0); 
					}else{ 
						localStorage.setItem('hidezones".$id."', 1); 
					}
					// console.log(localStorage.getItem('hidezones".$id."'));
				}
				if(localStorage.getItem('hidezones".$id."') == null) {localStorage.setItem('hidezones".$id."', 0);}
				if(localStorage.getItem('hidezones".$id."') == 1){ hidezones('#dashlet-'+'".$id."'); } else { showzones('#dashlet-'+'".$id."');}

				var dMMFTogglepercent = dashModMenuForm.appendChild(document.createElement('button'));
				dMMFTogglepercent.innerHTML = 'Toggle Percent';
				dMMFTogglepercent.value = 'TogglePercent';
				dMMFTogglepercent.classList.add('togglepercent');
				dMMFTogglepercent.style.width = '125px';
				// dMMFTogglepercent.style.height = '20px';
				dMMFTogglepercent.style.backgroundColor = '#444';
				dMMFTogglepercent.style.border = '3px solid #555';
				dMMFTogglepercent.onclick = function() { 
					if(localStorage.getItem('hidepercent".$id."') == 1) { 
						localStorage.setItem('hidepercent".$id."', 0); 
					}else{ 
						localStorage.setItem('hidepercent".$id."', 1); 
					}
					// console.log(localStorage.getItem('hidepercent".$id."'));
				}
				if(localStorage.getItem('hidepercent".$id."') == null) {localStorage.setItem('hidepercent".$id."', 0);}
				if(localStorage.getItem('hidepercent".$id."') == 1){ hidepercent('#dashlet-'+'".$id."'); } else { }


				
		// filter: drop-shadow(0 0 1px var(--color));
			
				</script>";
			
			break;

		case DASHLET_MODE_PREVIEW:
			$output="<img src='".get_dashlet_url_base("modern_gauge")."/modern_gauge.png' alt='No Preview Available' width='50%'/>";
			break;			
		}
		
	return $output;
}

function insert_modern_gauge_html($id) {
	$output = '
    <div class="'.$id.'">
	  
      <svg class="modern_gauge_svg">
        
        <circle cx="70" cy="70" r="70"></circle>
        <circle cx="70" cy="70" r="70"></circle>
        <circle cx="70" cy="70" r="70"></circle>
        <circle cx="70" cy="70" r="70"></circle>
        
        <line class="war" stroke="yellow"/>
        <line class="crt" stroke="red"/>
      </svg>
      <div class="gaugetext">
        <h2>0<span></span></h2>
        <p id="serviceName"></p>
		<p id="value"></p>
      </div>
    </div>';
	$output .= '
	<style>
	  '.$id.' {
		position: relative;
		/*scale: 1.1;*/ 
		transform: scale(1.5);
		width: 100%;
		height: 100%;
		background-color: purple;
		--num:0;
		--warinit:0;
		--crtinit:0;
	  }
	  
	  '.$id.' svg.modern_gauge_svg {
		position: absolute;
		inset: 50%;
		justify-content: center;
		align-items: center;
		scale: 1.0;
		width: 200px;
		height: 200px;
		transform: rotate(-90deg) translate(85px, -85px);
	  }
	  /* line markers */
	  '.$id.' svg.modern_gauge_svg line {
		opacity: 0.2;
		display: none;
	  }
	  /* all circles */
	  '.$id.' svg.modern_gauge_svg circle {
		align: right;
		position: absolute;
		width: 90%;
		height: 90%;
		fill: transparent;
		transform: translate(10px, 10px);
		stroke-width: 15;
		transition: 1s all; 
		transition-timing-function: cubic-bezier(0.05, 0.55, 0.85, 1.0);
	  }
	  /* background circle */
	  '.$id.' svg circle:nth-child(1){
		stroke: #222222;
		transition: none; 
	  }
	  /* current status circle */
	  '.$id.' svg circle:nth-child(4){
		--color: #00ff44;
		stroke: var(--color);
		stroke-dasharray: 440;
		stroke-dashoffset: 440;
		z-index:15;
		stroke-opacity:1;
		// filter: drop-shadow(0 0 1px var(--color));
	  }
	  /* warning range circle segment */
	  '.$id.' svg circle:nth-child(3){
		stroke: #C27C0E;
		stroke-dasharray: 440;
		z-index:5;
		stroke-opacity: 0.3;
		transition: none; 
		transform-box: fill-box;
		transform-origin: center;
	  }
	  /* critical range circle segment */
	  .'.$id.' svg circle:nth-child(2){
		stroke: #ac2925;
		stroke-dasharray: 440;
		z-index: 10;
		stroke-opacity: 0.25;
		transition: none; 
		transform-box: fill-box;
		transform-origin: center;
	  }
	  
	  
	  .'.$id.' .gaugetext {
		scale: 1.0;
		position: absolute;
		inset: 50%;
		justify-content: center;
		align-items: center;
		display: flex;
		flex-direction: column;
		transform: translateY(54px);
	  }
	  .'.$id.' .gaugetext h2 {
		--color: #EEE
		--units: "words";
		justify-content: center;
		align-items: center;
		display: flex;
		// font-weight:600;
		font-family: inherit;
		color: var(--color);
		font-size: 2.5em;
		// filter: drop-shadow(0 0 1px var(--color));
		transform: translateX(-4px);
	  }
	  .'.$id.' .gaugetext h2 span {
		font-weight:300;
		font-size:0.4em;
		transform: translateY(7px);
		color:#CCC;
		font-family: sans-serif;
	  }
	  .'.$id.' .gaugetext p#serviceName {
		font-weight:300;
		font-size:1.1em;
		margin-top: 30px;
		padding-bottom: 0;
		color:#CCC;
		transform: translate(-0.5em, -3em);
		font-family: sans-serif;
	  }
	  .'.$id.' .gaugetext p#value {
		font-weight:300;
		font-size:1.3em;
		margin-top: 6px;
		padding-bottom: 0px;
		color:#CCC;
		transform: translate(-0.5em, -3em);
		font-family: sans-serif;
		--show-percent: "%";
	  }
	  .'.$id.' .gaugetext p#value:after {
		content: var(--show-percent);
		font-weight:250;
		color:#DDD;
		font-size:0.9em;
		margin: 0px;
		transition: 1s all;
	  }
	  </style>';
	return $output;
}

// for some reason, the menus don't work when inserted as a function...
// function insert_modern_gauge_menu(){
// 	return
// }


function ajax_update_gauge($id, $args = null) {
	// get_current_gauge_value();

	//$args = array("host" => "www.twitter.com", "service" => "Ping", "ds" => "rta");
    $host = grab_array_var($args, "host", "");
    $service = urldecode(grab_array_var($args, "service", ""));
    $ds = grab_array_var($args, "ds", "");

	$displayed_title = ($service == "_HOST_") ? $host : "$host - $service";

	return '
	// console.log('.$host.','.$service.','.$ds.','.$displayed_title.');
	// Object.values('.json_encode($args).').forEach((key,val) => {
	// 	console.log(key,val);
	// });

	// console.log("jaxupdateargs "+'.json_encode($args).');
	var args = ['.$args.'];

	$url = "'.get_dashlet_url_base("modern_gauge") . '/getdata.php?host=' . $host . '&service=' . $service . '&ds=' . $ds . '";


	$.ajax({"url": $url, dataType: "json",
		"success": function(result) {
			console.table(result);
			updategauge("'.$id.'", result, "'.$host.'", "'.$service.'");
		}
	});

	// it seems the receiving URL starts returning the same data for all the dashlets. I do not know why this is.
	// setInterval(function() {  $.ajax({"url": $url, dataType: "json", id: "'.$id.'", host: "'.$host.'",
	// 	"success": function(result) {
	// 		updategauge(this.id, result, this.host);
	// 	}
	// }); }, ' . get_dashlet_refresh_rate(60, "perfdata_chart") . ');

	setTimeout(() => {
		location.reload();
	}, "' . get_dashlet_refresh_rate(60, "perfdata_chart") . '");

';
}
