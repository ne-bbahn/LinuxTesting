    // Set colors for current status bar (not background zones)
    // const critColor = '#FF795F'; //service status page red
    const critColor = '#F96c59';  
    const warnColor = '#FEFF5F';  //service status page yellow
    const okColor = '#5CDF45';    //monitoring engine graph



// function setColors(cur,war,crt){
//     document.querySelector(id+' svg circle:nth-child(4)').style.setProperty('--stroke',cur);
//     document.querySelector(id+' svg circle:nth-child(3)').style.setProperty('--stroke',war);
//     document.querySelector(id+' svg circle:nth-child(2)').style.setProperty('--stroke',crt);
//   }

$('.dashletconfigure').click(function() {
  console.log('config');
  $('.dashlet-modify-menu').querySelector('div.dashlet-modify-menu').toggle();
});

function setstrokewidth(id, num) {
  console.log('#dashlet-'+id, num);
  document.querySelector('#dashlet-'+id+' svg circle').style.setProperty('stroke-width',num);
}

  

  function updategauge(id, args, host, service){
    // console.log(" \nhost: "+host+"\n");
    // console.log(id+" values:");
    // console.log(" \n");
    // console.log('#dashlet-'+id);
    // console.table(args);
    // console.log(args["current"]);
    console.log(args);
    
    document.querySelector('#dashlet-'+id).querySelector(' .gaugetext p#serviceName').innerHTML = args['label'];
    document.querySelector('#dashletcontainer-'+id+' .dashlettopbox .dashlettitle').innerHTML = 'Modern Gauge Dashlet - ' + host+' - '+ service+' - '+args['label'];


    // args['current'] = args['warn'] + 1;
    setvalhelper('#dashlet-'+id, args['current'],args['warn'],args['crit'], args['max'], args['uom']);
  }
  
  function setvalhelper(id, num, war, crt, max, unit) {  

    const gaugedashlet = document.querySelector(id);
    const r = gaugedashlet.querySelector('svg circle:nth-child(4)').getAttribute('r');

    

    //// no longer implemented since it looks bad
    //create warning tick mark
    // setTick(war,'.war');
    // setTick(crt,'.crt');

    // console.log("id = "+id);

    //fix swapped warning & critical values
    if(parseInt(war) > parseInt(crt)){
      const tmp = war;
      war = crt;
      crt = tmp;
    }

    // function tableitems(id,num,war,crt,max){
    //   this.id = id;
    //   this.num = num;
    //   this.war = war;
    //   this.crt = crt;
    //   this.max = max;
    // }
    // console.table(new tableitems(id,num,war,crt,max));


    var span = document.querySelector(id).querySelector('.gaugetext h2 span')
    span.innerHTML = unit;
    document.querySelector(id).querySelector('.gaugetext h2').innerHTML = num;
    console.log(Math.max(0,num.toString().length));
    document.querySelector(id).querySelector('.gaugetext h2').style.fontSize = (2.5-(0.25*(Math.max(0,num.toString().length-4))))+'em';
    $(id+' .gaugetext h2').append(span);
    console.log(document.querySelector(id).querySelector('.gaugetext h2').style.fontSize);
    

    //adjust values into percentages
    num = num*100/max;
    war = war*100/max;
    crt = crt*100/max;

    // console.table(new tableitems(id,num,war,crt,max));

    
    //change color based on warning/critical
    if (parseInt(num) >= parseInt(crt)){ //critical
      setpercentcolor(id,critColor);
    } else if (parseInt(num) >= parseInt(war)){ //warning
      setpercentcolor(id,warnColor);
    } else { //ok
      setpercentcolor(id,okColor);
    }
  
    document.querySelector(id).style.setProperty('--num',num);
    
    //definition of stroke -- necessary for some browsers
    gaugedashlet.querySelector(id+' svg circle:nth-child(4)').style['stroke-dashoffset'] = (arclen(num, r));
    
    //warning
    gaugedashlet.querySelector(id+' svg circle:nth-child(3)').style['stroke-dashoffset'] = (arclen(crt-war, r));
    gaugedashlet.querySelector(id+' svg circle:nth-child(3)').style['transform'] = 'translate(10px, 10px) rotate('+p2d(war)+'deg)';
    
    //critical
    gaugedashlet.querySelector(id+' svg circle:nth-child(2)').style['stroke-dashoffset'] = (arclen(100-crt, r));
    gaugedashlet.querySelector(id+' svg circle:nth-child(2)').style['transform'] = 'translate(10px, 10px) rotate('+(p2d(crt)+0.35)+'deg)'; // add 0.35 deg to compensate for machine error causing overlap


    if(num > 100) { // current value > max value, gauge will not work properly
      gaugedashlet.querySelector(id+' .gaugetext p#value').style.setProperty('display', 'none');
      gaugedashlet.querySelector(id+' svg circle:nth-child(4)').style['stroke-dashoffset'] = (arclen(100, r));
    } else {
      gaugedashlet.querySelector(id+' .gaugetext p#value').innerHTML = (num).toFixed(2);
    }
  } 
  
  // percent to degrees
  function p2d(num){
    return 3.6*num;
  }
  
  //converts percent of circle to dasharray length
  function arclen(num, r){
    return (r2pi(r)- (r2pi(r) * (num/100)));
  }
  //find how long an arc that completes a full circle should be based on circle radius
  function r2pi(r){
    return 2*Math.PI*r;
  }


  //// tick marks not implemented in final product since they look terrible imo
  //set tick marks if applied
  // function setTick(num, tag) {
  //   const cx = 80;
  //   const cy = 80;
  //   num += 25;
  
  //   wx1=cx+(Math.sin(Math.PI*num/50))*75;
  //   wx2=cx+(Math.sin(Math.PI*num/50))*65;
  //   wy1=cy-(Math.cos(Math.PI*num/50))*75;
  //   wy2=cy-(Math.cos(Math.PI*num/50))*65;
  //   const warelem = document.querySelector(tag);
  //   warelem.setAttribute('x1', wx1);
  //   warelem.setAttribute('x2', wx2);
  //   warelem.setAttribute('y1', wy1);
  //   warelem.setAttribute('y2', wy2);
  // }
  
  
  
  function setpercentcolor(id,color){
    document.querySelector(id+' svg circle:nth-child(4)').style.setProperty('--color',color);
    
    // document.querySelector(id+' .gaugetext > *').style.setProperty('--color', colorsubdue(color,4));
    document.querySelector(id+' .gaugetext > *').style.setProperty('--color', colorsubdue(color,2));

    // console.log(document.querySelector(id));
  }
  function colorsubdue(color, degree){
    //subdue the color for the center stuff
    color = color.substring(1, color.length).toLowerCase(); //remove # and set to lowercase
    
    numlist = '0123456789abcdef';
    numlist = '0'.repeat(degree) + numlist;
    
    for (i=0; i<color.length; i++){
      color = color.substring(0,i) + 
      numlist[numlist.indexOf(color[i], degree) - degree] + 
      color.substring(i+1,color.length);
    }
    return '#'+color;
  }
  
  
  function hidezones(id){
    document.querySelector(id+' svg circle:nth-child(3)').style['display'] = 'none';
    document.querySelector(id+' svg circle:nth-child(2)').style['display'] = 'none';
  }
  function showzones(id){
    document.querySelector(id+' svg circle:nth-child(3)').style['display'] = 'block';
    document.querySelector(id+' svg circle:nth-child(2)').style['display'] = 'block';
  }

  function hidepercent(id){
    console.log(id);
    document.querySelector(id+' .gaugetext p#value').style['display'] = 'none';
    document.querySelector(id+' .gaugetext p#value').style['display'] = 'none';
    console.log(id);
  }


  function hidetickmarks(id){
    document.querySelector(id+' svg .war').style['display'] = 'none';
    document.querySelector(id+' svg .crt').style['display'] = 'none';
  }
  
  // hidezones();
  // hidetickmarks();




  //////customizability functions

  function no_glow(){
    // drop shadow none
  }

  function no_indicators(warn,crit){
    // ((warn == false)? : );
    // ((crit == false)? : );
  }