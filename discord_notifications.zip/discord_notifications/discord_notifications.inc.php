<?php
//
// Website URL Config Wizard
// Copyright (c) 2008-2021 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

discordnoti_configwizard_init();

function discordnoti_configwizard_init()
{
    $name = "discordnoti";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.0.0",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Send Notifications to Discord! :D"),
        CONFIGWIZARD_DISPLAYTITLE => _("Discord Notifications"),
        CONFIGWIZARD_FUNCTION => "discordnoti_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "discord.png"
    );
    register_configwizard($name, $args);
}


/**
 * @param string $mode
 * @param        $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function discordnoti_configwizard_func($mode = "", $inargs, &$outargs, &$result)
{
    $wizard_name = "discordnoti";

    // Initialize return code and output
    $result = 0;

    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $url = grab_array_var($inargs, "url", "");
            $host = grab_array_var($host, "host", "");

            $output = '
<h5 class="ul">' . _('Setup Instructions') . '</h5>
    <ul style="padding: 0 0 0 30px;">
        <li><a href="sample.pdf" target="_blank">' . _('View Setup Instructions PDF') . '</a> in a new tab.</li>
    </ul>
<h5 class="ul">' . _('URL Information') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>' . _('Webhook URL') . ':</label>
        </td>
        <td>
            <input type="text" size="60" name="url" id="url" value="' . encode_form_val($url) . '" class="form-control">
            <div class="subtext">' . _('Paste the Discord Webhook URL here.') . '</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Host Name') . ':</label>
        </td>
        <td>
            <select class="form-control" name="host">
                <OPTION VALUE=""></OPTION>';

                $args = array("is_active" => 1);
                $xmlhosts = get_xml_host_objects($args);
                $hosts = array();
                foreach ($xmlhosts->host as $h) {
                    $hosts[] = $h;
                }
                $hosts = array_reverse($hosts);

                foreach ($hosts as $h) {
                    $hname = strval($h->host_name);
                    $hdesc = $hname;
                    $halias = strval($h->alias);
                    if ($halias != $hname && $halias != "") {
                        $hdesc .= " (" . $halias . ")";
                    }
                    $output .= '<OPTION VALUE="' . $hname . '" ' . is_selected($host, $hname) . '>' . $hdesc . '</OPTION>';
                }

                $output .= '
            </select>
            <div class="subtext">' . _('Select an existing host that should be cloned and used as the template for new hosts') . '.</div>
        </td>
    </tr>
</table>';

var_dump("    ",$host,$hostname,have_value($host),host_exists($host));
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            
            // Get variables that were passed to us
            $url = grab_array_var($inargs, "url");
            $url = nagiosccm_replace_user_macros($url);
            $host = grab_array_var($inargs, "host", "");

            

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (have_value($url) == false)
                $errmsg[$errors++] = _("No URL specified.");
            else if (!valid_url($url))
                $errmsg[$errors++] = _("Invalid URL.");

            if (have_value($host) == false) {
                $errmsg[$errors++] = _("No template host specified.");
            } else if (host_exists($host) == false) {
                $errmsg[$errors++] = _("Template host could not be found.");
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $url = grab_array_var($inargs, "url");
            $host = grab_array_var($inargs, "host", "");            

            $output = '
<input type="hidden" name="url" value="' . encode_form_val($url) . '">
<input type="hidden" name="host" value="'.encode_form_val($host).'"

<h5 class="ul">' . _('URL Details') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>' . _('Webhook URL') . ':</label>
        </td>
        <td>
            <a href="' . encode_form_val($url) . '" target="_blank">' . encode_form_val($url) . '</a><br>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _("The host you will receive notifications from") . ':</label>
        </td>
        <td>
            <input type="text" size="20" name="host id="host" value="'.encode_form_val($host).'" class="form-control" disabled>
            <div class="subtext">' . _('This is the host you will receive notifications from.'.encode_form_val($host).'') . '</div>
        </td>
    </tr>
</table>
';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // Get variables that were passed to us
            $url = grab_array_var($inargs, "url");
            $host = grab_array_var($inargs, "host");

            //

            // Check for errors
            $errors = 0;
            $errmsg = array();


            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;
// verified works correctly through here

        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // Get variables that were passed to us
            $url = grab_array_var($inargs, "url");
            $host = grab_array_var($inargs, "host", "");

            //print("<p style='color:#fff'>".print_r($host, true)."</p>");
            $output = '
        <input type="hidden" name="url" value="' . encode_form_val($url) . '">
        <input type="hidden" name="host" value="' . encode_form_val($host) . '">
';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '
            
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:
            $url = grab_array_var($inargs, "url");
            $host = grab_array_var($inargs, "host");


            //$pluginargument = $url." ".$host." ".
            $pluginargument = $url."!$"."HOSTNAME$!$"."HOSTADDRESS$!$"."HOSTSTATE$!$"."HOSTOUTPUT$!$"."LONGDATETIME$";


            //print("<pre style='color:#fff'>".print_r($pluginargument, true)."<pre>");
            
            $objs[] = array(
                "type" => OBJECTTYPE_HOST,
                "use" => "xiwizard_wizarddemo_host",
                "host_name" => $host,
                "event_handler" => "discordCurl!".$pluginargument,
                "max_check_attempts" => 1,
                "_xiwizard" => $wizard_name,
            );

            
            //echo "OBJECTS:<BR>";
            //print("<pre style='color:#fff'>".print_r($objs, true)."<pre>");
            

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}

/**
 * @param $url
 *
 * @return mixed|string
 */
