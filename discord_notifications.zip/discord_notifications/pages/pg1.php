<?php '
<h5 class="ul">' . _('Setup Instructions') . '</h5>
    <ul style="padding: 0 0 0 30px;">
        <li><a href="sample.pdf" target="_blank">' . _('View Setup Instructions PDF') . '</a> in a new tab.</li>
    </ul>
<h5 class="ul">' . _('URL Information') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>' . _('URL') . ':</label>
        </td>
        <td>
            <input type="text" size="60" name="url" id="url" value="' . encode_form_val($url) . '" class="form-control">
            <div class="subtext">' . _('Paste the Discord Webhook URL here.') . '</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('BB First Input') . ':</label>
        </td>
        <td>
            <input type="text" size="60" name="firstinput" id="first-input" value="'.encode_form_val($veryimportantinput).'" class="form-control">
            <div class="subtext">' . _("Enter whatever your heart desires. It won't do anything and definitely won't be used to evaluate your mental stability.") . '</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Host') . ':</label>
        </td>
        <td>
            <div class="popup-form-box"><label>' . _('Host') . '</label>
                <div><select id="gauges_form_name" class="form-control" name="host" onchange="getgaugejson()">
                <option selected></option>
        </td>
    </tr>
</table>';
                $output .= '<script type="text/javascript" src="getdata.js">load_discord_hosts();</script>';
                $output .= '<div class="popup-form-box"><label>' . _('Host') . '</label>
                            <div><select id="gauges_form_name" class="form-control" name="host" onchange="getgaugejson()">
                                    <option selected></option>';
                $output .= '</select> <i class="fa fa-spinner fa-spin fa-14 hide host-loader" title="'._('Loading').'"></i></div></div>';
?>