#!/bin/bash
# curl -H "Content-Type: application/json" -d '{"username":"test","content":"hello"}' "https://discordapp.com/api/webhooks/1026960031360491651/SIPz-NzlX83q7IvkyArLqAwQr9DYbG-obrCCGPKi__q28oqwdWNYYMdYdKADiE75cCEu"

# updates log when executes:
#echo "10/19/22" >> /tmp/discCurl.log


#
#	command: discordCurl.sh webhook-url "$NOTIFICATIONTYPE$" "$HOSTNAME$" "$HOSTADDRESS$" "$HOSTSTATE$" "$HOSTOUTPUT$" "$LONGDATETIME$"
#

### Colors:
#Default   0   #000000
#Aqua  1752220   #1ABC9C
#DarkAqua  1146986   #11806A
#Green   5763719   #57F287
#DarkGreen   2067276   #1F8B4C
#Blue  3447003   #3498DB
#DarkBlue  2123412   #206694
#Purple  10181046  #9B59B6
#DarkPurple  7419530   #71368A
#LuminousVividPink   15277667  #E91E63
#DarkVividPink   11342935  #AD1457
#Gold  15844367  #F1C40F
#DarkGold  12745742  #C27C0E
#Orange  15105570  #E67E22
#DarkOrange  11027200  #A84300
#Red   15548997  #ED4245
#DarkRed   10038562  #992D22
#Grey  9807270   #95A5A6
#DarkGrey  9936031   #979C9F
#DarkerGrey  8359053   #7F8C8D
#LightGrey   12370112  #BCC0C0
#Navy  3426654   #34495E
#DarkNavy  2899536   #2C3E50
#Yellow  16776960  #FFFF00



wEBHOOK_URL=$1 # webhook url consists of https://discordapp.com/api/webhooks/ id / token


echo ""
IFS='/' read -a ADDR <<< "$IN"
for i in "${ADDR[@]}"; do
    echo "$i"
done
echo ""


nOTIFICATION_TYPE=$2
hOSTNAME=$3
hOSTADDRESS=$4
hOSTSTATE=$5
hOSTOUTPUT=$6
dATETIME=$7

case $hOSTOUTPUT in # takes in $HOSTSTATE$ and sets message color accordingly
"CRITICAL")
  cOLOR="15548997"
  dESC=":scream:"
  rTRN=2
  ;;
"WARNING")
  cOLOR="16705372"
  dESC=":sweat:"
  rTRN=1
  ;;
"OK")
  cOLOR="5763719"
  dESC=":smiley:"
  rTRN=0
  ;;
*)
  cOLOR="5793266"
  dESC="UNKNOWN"
  rTRN=3
  ;;
esac

if [ "$dESC" == "UNKNOWN" ]; then
  case $hOSTSTATE in
    "DOWN")
      cOLOR="15548997"
      dESC="DOWN...:scream:"
      rTRN=2
      ;;
    "UP")
      cOLOR="5763719"
      dESC="UP...:smiley:"
      rTRN=0
      ;;
    "UNCREACHABLE")
      cOLOR="16705372"
      dESC="UNKNOWN...:sweat:"
      rTRN=1
      ;;
  esac
fi

#echo "" >> /tmp/discCurl

#echo ""


dISCORD_JSON='{"username":"'"$hOSTNAME"'","embeds":[{"title":"'"$hOSTNAME"'_Update","description":"'"$dESC"'","color":"'"$cOLOR"'","fields":[{"name":"Host_Address:","value":"'"$hOSTADDRESS"'","inline":true},{"name":"Host_State:","value":"'"$hOSTSTATE"'","inline":true},{"name":"Host_Output","value":"'"$hOSTOUTPUT"'"}],"footer":{"text":"'"$dATETIME"'"}}]}'


# replace those f%&^ing spaces with underscores so curl doesn't break
dISCORD_JSON=${dISCORD_JSON// /_}

#echo "$dISCORD_JSON" >> /tmp/discCurl

#Send message to Discord
curl -g -X POST -H "Content-Type: application/json" -d $dISCORD_JSON $wEBHOOK_URL

#result=$(curl -g -X POST -H "Content-Type: application/json" -d $dISCORD_JSON $wEBHOOK_URL)

#echo ""
#echo "$result" >> /tmp/resultlog
#echo ""

#echo "$rTRN" >> /tmp/resultlog


#echo ""
#echo "executed"