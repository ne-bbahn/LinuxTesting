function load_discord_hosts()
{
    var url = base_url + "includes/configwizards/discord_notifications/getdata.php";
    $('.host-loader').show();

    // Get all services with data
    $.ajax({
        "url": url,
        data: { 'cmd': 'noperfdata' },
        "success": function (result) {

            $('.host-loader').hide();

            hosts = result;
            var hostslist = "<option selected></option>";
            $(hosts).each(function(k, v) {
                hostslist += "<option value='" + v + "'>" + v + "</option>";
            });
            $('#discord_form_name').html(hostslist);
        }
    });
}

function gethostjson()
{
    var url = base_url + "includes/configwizards/discord_notifications/getdata.php";
    var host = $('#discord_form_name').val();

    if (host == '') {
        $('#discord_form_services').html("<option selected></option>");
        $('#discord_form_services').prop('disabled', true);
        $('#empty-services').hide();
        $('#discord_form_services').show();
        return;
    }

    // Set loading...
    $('.service-loader').show();
    $('#discord_form_ds').prop('disabled', true);

    // Get all services with data
    $.ajax({
        "url": url,
        data: { 'host': host, 'cmd': 'noperfdata' },
        "success": function (result) {

            $('.service-loader').hide();

            // If services are empty
            if (result.length == 0) {
                $('#discord_form_services').hide();
                $('#empty-services').show();
                return;
            } else {
                $('#discord_form_services').show();
                $('#empty-services').hide();
            }

            services = result;
            var servicelist = "<option selected></option>";
            $(services).each(function(k, v) {
                servicelist += "<option value='" + v + "'>" + v + "</option>";
            });
            $('#discord_form_services').html(servicelist);

            // Remove disabled
            $('#discord_form_services').prop('disabled', false);
        }
    });
}